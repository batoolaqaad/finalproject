function onmouseOver(){
document.getElementById("demo").style.backgroundColor="purple";}
function Myfunction(){
document.getElementById("demo").style.backgroundColor="pink";}

function myFunction(){
    document.getElementById("ks").style.backgroundColor="pink";}
    function MyfunctIon(){
    document.getElementById("ks").style.backgroundColor="white";}
 